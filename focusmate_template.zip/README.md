FocusMate - Android için ders çalışma asistanı (Proje şablonu)
==============================================================

Selam Burak! 🎯
Ben senin için Android'de çalıştırabileceğin bir Flutter proje şablonu hazırladım. Ben burada doğrudan bir .apk derleyemiyorum ama sana tamamen çalıştırılabilir bir proje iskeleti veriyorum; bilgisayarında Flutter yüklüyse aşağıdaki adımlarla APK'yı kolayca oluşturabilirsin.

Özet: Bu paket `lib/main.dart`, `pubspec.yaml` ve birkaç yardımcı dosya içerir. Yapman gerekenler:
1. Bilgisayarında Flutter kurulu olmalı. (https://flutter.dev/docs/get-started/install)
2. Aşağıdaki komutları çalıştır:
   ```bash
   flutter create focusmate_app
   cd focusmate_app
   # lib klasörünü yedekle veya sil
   rm -rf lib
   # Bu paket içindeki lib klasörünü kopyala
   cp -r /path/to/extracted/focusmate_template/lib ./lib
   # pubspec.yaml içeriğini proje pubspec.yaml ile birleştir (dependencies kısmını güncelle)
   # Alternatif: focusmate_template/pubspec.yaml içeriğini proje pubspec.yaml ile değiştir
   flutter pub get
   flutter build apk --release
   ```

Notlar ve Öneriler
- Eğer Flutter kurulu değilse `flutter create` komutu otomatik gerekli Android Gradle dosyalarını oluşturur; bu yüzden template içindeki sadece `lib` ve `assets` dosyalarını verdiğim şekilde projene eklemen yeterli.
- Uygulamada bildirim ve arka plan zamanlayıcıları için ek konfigürasyon gerekebilir; şu anki sürüm basit ve cihazda yerel olarak çalışır, planları `shared_preferences` ile saklar.
- İstersen ben bu projeyi genişletip bildirim, otomatik başlatma, deneme sınavı zamanlayıcısı ve istatistik ekranı ekleyebilirim. Bana "Geliştir" de.

Dosya listesi (bu zip içinde):
- lib/main.dart  -> Uygulamanın ana kodu
- pubspec.yaml   -> Bağımlılıklar
- assets/motivation.txt -> Motivasyon satırları

İyi çalışmalar! 💪
