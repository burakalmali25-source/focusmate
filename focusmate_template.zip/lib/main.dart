import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(FocusMateApp());
}

class FocusMateApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'FocusMate',
      theme: ThemeData(
        primarySwatch: Colors.indigo,
        brightness: Brightness.light,
      ),
      home: HomePage(),
    );
  }
}

class StudySession {
  String subject;
  TimeOfDay start;
  TimeOfDay end;
  bool done;

  StudySession({required this.subject, required this.start, required this.end, this.done = false});

  Map<String, dynamic> toJson() => {
        'subject': subject,
        'start': '${start.hour.toString().padLeft(2,'0')}:${start.minute.toString().padLeft(2,'0')}',
        'end': '${end.hour.toString().padLeft(2,'0')}:${end.minute.toString().padLeft(2,'0')}',
        'done': done
      };

  static StudySession fromJson(Map<String, dynamic> j) {
    List<String> s = (j['start'] as String).split(':');
    List<String> e = (j['end'] as String).split(':');
    return StudySession(
        subject: j['subject'],
        start: TimeOfDay(hour: int.parse(s[0]), minute: int.parse(s[1])),
        end: TimeOfDay(hour: int.parse(e[0]), minute: int.parse(e[1])),
        done: j['done'] ?? false);
  }

  String timeRange() => '${start.format(const TimeOfDayFormatHolder.context)} - ${end.format(const TimeOfDayFormatHolder.context)}';
}

// Helper to format TimeOfDay without importing intl package
extension TimeOfDayFormat on TimeOfDay {
  String formatLocal(BuildContext context) {
    final hourStr = hour.toString().padLeft(2, '0');
    final minStr = minute.toString().padLeft(2, '0');
    return '$hourStr:$minStr';
  }
}

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List<StudySession> today = [];
  List<String> subjects = ['Matematik','Fizik','Kimya','Biyoloji','Geometri','TYT Deneme','AYT Tekrar'];
  int targetHours = 10;
  TimeOfDay wake = TimeOfDay(hour:7, minute:0);
  TimeOfDay sleep = TimeOfDay(hour:0, minute:0);
  bool loaded = false;

  @override
  void initState() {
    super.initState();
    _loadPrefs();
  }

  Future<void> _loadPrefs() async {
    final p = await SharedPreferences.getInstance();
    targetHours = p.getInt('targetHours') ?? 10;
    subjects = p.getStringList('subjects') ?? subjects;
    String? raw = p.getString('todayPlan');
    if (raw != null) {
      List dec = json.decode(raw);
      today = dec.map((e) => StudySession.fromJson(e)).toList();
    } else {
      _generatePlanAndSave();
    }
    setState(() => loaded = true);
  }

  Future<void> _savePlan() async {
    final p = await SharedPreferences.getInstance();
    final enc = json.encode(today.map((s) => s.toJson()).toList());
    await p.setString('todayPlan', enc);
    await p.setInt('targetHours', targetHours);
    await p.setStringList('subjects', subjects);
  }

  void _generatePlanAndSave() {
    // Generate contiguous study blocks between 07:30 and 23:30, fitting targetHours.
    // Strategy: create blocks of 90-120 minutes with 15 minute breaks.
    today.clear();
    final availableStart = TimeOfDay(hour:7, minute:30);
    final availableEnd = TimeOfDay(hour:23, minute:30);
    int totalMinutes = targetHours * 60;
    int pointerHour = availableStart.hour;
    int pointerMin = availableStart.minute;
    int subjIndex = 0;

    while (totalMinutes > 0) {
      // block length between 90 and 120, prefer 120 if possible
      int block = totalMinutes >= 120 ? 120 : (totalMinutes >= 90 ? 90 : totalMinutes);
      // create start and end
      TimeOfDay s = TimeOfDay(hour: pointerHour, minute: pointerMin);
      int endMinutes = pointerHour * 60 + pointerMin + block;
      if (endMinutes > availableEnd.hour * 60 + availableEnd.minute) {
        // move earlier break: reduce block to fit
        block = (availableEnd.hour * 60 + availableEnd.minute) - (pointerHour * 60 + pointerMin);
        endMinutes = pointerHour * 60 + pointerMin + block;
      }
      TimeOfDay e = TimeOfDay(hour: endMinutes ~/ 60, minute: endMinutes % 60);
      String subj = subjects[subjIndex % subjects.length];
      today.add(StudySession(subject: subj, start: s, end: e));
      totalMinutes -= block;
      // advance pointer by block + 15min break
      int nextPointer = endMinutes + 15;
      if (nextPointer > availableEnd.hour * 60 + availableEnd.minute) break;
      pointerHour = nextPointer ~/ 60;
      pointerMin = nextPointer % 60;
      subjIndex++;
    }
    _savePlan();
  }

  void _resetProgress() async {
    for (var s in today) s.done = false;
    await _savePlan();
    setState(() {});
  }

  void _markDone(int idx) async {
    today[idx].done = true;
    await _savePlan();
    setState(() {});
  }

  int _completedMinutes() {
    int sum = 0;
    for (var s in today) {
      if (s.done) {
        int sh = s.start.hour*60 + s.start.minute;
        int eh = s.end.hour*60 + s.end.minute;
        sum += (eh - sh);
      }
    }
    return sum;
  }

  @override
  Widget build(BuildContext context) {
    if (!loaded) return Scaffold(body: Center(child: CircularProgressIndicator()));
    int completed = _completedMinutes();
    int targetMin = targetHours * 60;
    return Scaffold(
      appBar: AppBar(
        title: Text('FocusMate'),
        actions: [
          IconButton(icon: Icon(Icons.settings), onPressed: () async {
            await Navigator.push(context, MaterialPageRoute(builder: (_) => SettingsPage(
              targetHours: targetHours,
              subjects: subjects,
              onSaved: (h, subs) {
                targetHours = h;
                subjects = subs;
                _generatePlanAndSave();
              },
            )));
            setState(() {});
          })
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Bugün hedef: $targetHours saat', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            SizedBox(height:8),
            LinearProgressIndicator(value: completed / (targetMin==0?1:targetMin)),
            SizedBox(height:8),
            Text('Tamamlanan: ${ (completed/60).toStringAsFixed(1) } saat', style: TextStyle(fontSize:16)),
            SizedBox(height:12),
            Expanded(
              child: ListView.builder(
                itemCount: today.length,
                itemBuilder: (_, i){
                  final s = today[i];
                  int duration = (s.end.hour*60+s.end.minute) - (s.start.hour*60+s.start.minute);
                  return Card(
                    child: ListTile(
                      title: Text(s.subject),
                      subtitle: Text('${s.start.formatLocal(context)} - ${s.end.formatLocal(context)} • ${ (duration/60).toStringAsFixed(1) } saat'),
                      trailing: s.done ? Icon(Icons.check_circle, color: Colors.green) : ElevatedButton(onPressed: () => _markDone(i), child: Text('Bitti')),
                    ),
                  );
                },
              ),
            ),
            Row(
              children: [
                ElevatedButton.icon(onPressed: ()=> _generatePlanAndSave(), icon: Icon(Icons.shuffle), label: Text('Yeniden Planla')),
                SizedBox(width:8),
                ElevatedButton.icon(onPressed: ()=> _resetProgress(), icon: Icon(Icons.refresh), label: Text('Sıfırla')),
              ],
            ),
            SizedBox(height:8),
            Center(child: Text('Motivasyon: \"Çalış, sınav seni değil sen sınavı yenersin!\"')),
            SizedBox(height:12),
          ],
        ),
      ),
    );
  }
}

class SettingsPage extends StatefulWidget {
  final int targetHours;
  final List<String> subjects;
  final void Function(int, List<String>) onSaved;
  SettingsPage({required this.targetHours, required this.subjects, required this.onSaved});
  @override
  _SettingsPageState createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  late int hours;
  late List<String> subs;
  TextEditingController newSub = TextEditingController();

  @override
  void initState(){ super.initState(); hours = widget.targetHours; subs = List.from(widget.subjects); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Ayarlar')),
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Column(
          children: [
            Row(
              children: [
                Text('Günlük hedef saat: ', style: TextStyle(fontSize:16)),
                Spacer(),
                DropdownButton<int>(value: hours, items: List.generate(3, (i)=>10+i).map((h)=>DropdownMenuItem(value:h, child: Text('$h'))).toList(), onChanged: (v){ if(v!=null) setState(()=>hours=v); })
              ],
            ),
            SizedBox(height:12),
            Text('Dersler', style: TextStyle(fontSize:16, fontWeight: FontWeight.bold)),
            Expanded(child: ListView.builder(itemCount: subs.length, itemBuilder: (_,i){
              return ListTile(
                title: Text(subs[i]),
                trailing: IconButton(icon: Icon(Icons.delete), onPressed: ()=> setState(()=>subs.removeAt(i))),
              );
            })),
            Row(children: [
              Expanded(child: TextField(controller: newSub, decoration: InputDecoration(hintText: 'Yeni ders adı'))),
              SizedBox(width:8),
              ElevatedButton(onPressed: (){ if(newSub.text.trim().isNotEmpty){ setState(()=>subs.add(newSub.text.trim())); newSub.clear(); } }, child: Text('Ekle'))
            ]),
            SizedBox(height:12),
            ElevatedButton(onPressed: (){
              widget.onSaved(hours, subs);
              Navigator.pop(context);
            }, child: Text('Kaydet'))
          ],
        ),
      ),
    );
  }
}

// Small helper to satisfy earlier TimeOfDay.format usage in StudySession.timeRange()
class TimeOfDayFormatHolder {
  static late BuildContext context;
  const TimeOfDayFormatHolder();
}
